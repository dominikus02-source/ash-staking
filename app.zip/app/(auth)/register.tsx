import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useRouter, Link } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../../src/lib/firebase';

export default function RegisterScreen() {
  const router = useRouter();
  
  const [formData, setFormData] = useState({
    displayName: '',
    email: '',
    password: '',
    confirmPassword: '',
    username: '', // Opsional jika ingin kustom
    referralCode: '', 
  });
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    // 1. Bersihkan Input
    const cleanEmail = formData.email.trim();
    const cleanDisplayName = formData.displayName.trim();
    const cleanReferral = formData.referralCode.trim().toUpperCase();
    const cleanUsername = formData.username.trim().toLowerCase();

    // 2. Validasi Dasar (Diperketat)
    if (!cleanDisplayName || !cleanEmail || !formData.password) {
      Alert.alert('⚠️ Input Kosong', 'Nama, Email, dan Password wajib diisi!');
      return;
    }

    if (formData.password.length < 6) {
      Alert.alert('⚠️ Password Lemah', 'Password minimal harus 6 karakter!');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert('⚠️ Password Tidak Sama', 'Konfirmasi password tidak cocok!');
      return;
    }

    setLoading(true);
    try {
      // 3. Buat Akun di Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        cleanEmail,
        formData.password
      );
      const user = userCredential.user;

      // 4. Update Profil Auth (Sangat disarankan agar data user.displayName segera tersedia)
      await updateProfile(user, {
        displayName: cleanDisplayName,
      });

      // 5. Generate Kode Referral Baru (Gunakan 6 digit akhir UID agar lebih unik)
      const myReferralCode = user.uid.substring(user.uid.length - 6).toUpperCase();

      // 6. Simpan Data ke Firestore
      // Menggunakan setDoc agar ID di Firestore SAMA dengan UID di Auth
      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        email: user.email,
        displayName: cleanDisplayName,
        username: cleanUsername || `miner_${Math.floor(1000 + Math.random() * 9000)}`,
        
        // --- DATA MINING & BALANCING ---
        balance: 2.0, // Bonus Welcome
        mining: { 
          isActive: false, 
          startTime: null, 
          lastSync: Date.now() 
        },
        boosts: { normalEndTime: 0, premiumEndTime: 0 },
        lastDailyClaim: 0,

        // --- SISTEM REFERRAL ---
        referralCode: myReferralCode, 
        referredBy: cleanReferral || null, 
        referralCount: 0,
        
        // --- STATUS & TIMESTAMP ---
        createdAt: serverTimestamp(),
        kycStatus: 'none',
        isPremium: false,
        lastLogin: serverTimestamp()
      });

      console.log('[REGISTER] ✅ Account Created:', user.email);
      
      // Menggunakan replace agar tidak bisa back ke register
      router.replace('/(main)/dashboard');

    } catch (error: any) {
      console.error('[REGISTER] ❌ Error Code:', error.code);
      let message = 'Terjadi kesalahan sistem.';
      
      if (error.code === 'auth/email-already-in-use') {
        message = 'Email ini sudah terdaftar. Silakan login.';
      } else if (error.code === 'auth/invalid-email') {
        message = 'Format email tidak valid.';
      } else if (error.code === 'auth/weak-password') {
        message = 'Password terlalu lemah.';
      } else if (error.code === 'auth/network-request-failed') {
        message = 'Koneksi internet terputus.';
      }
      
      Alert.alert('Registrasi Gagal', message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <Text style={styles.logo}>ASH</Text>
            <Text style={styles.title}>JOIN NOW</Text>
            <Text style={styles.subtitle}>Start Your Mining Journey</Text>
          </View>

          <View style={styles.form}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Full Name</Text>
              <TextInput
                style={styles.input}
                placeholder="Nama Lengkap"
                placeholderTextColor="#64748b"
                value={formData.displayName}
                onChangeText={(v) => setFormData({ ...formData, displayName: v })}
                autoCorrect={false}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="email@provider.com"
                placeholderTextColor="#64748b"
                value={formData.email}
                onChangeText={(v) => setFormData({ ...formData, email: v })}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={styles.input}
                placeholder="Minimal 6 karakter"
                placeholderTextColor="#64748b"
                value={formData.password}
                onChangeText={(v) => setFormData({ ...formData, password: v })}
                secureTextEntry
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Confirm Password</Text>
              <TextInput
                style={styles.input}
                placeholder="Ulangi password"
                placeholderTextColor="#64748b"
                value={formData.confirmPassword}
                onChangeText={(v) => setFormData({ ...formData, confirmPassword: v })}
                secureTextEntry
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Referral Code (Opsional)</Text>
              <TextInput
                style={[styles.input, styles.referralInput]}
                placeholder="Masukkan kode teman"
                placeholderTextColor="#64748b"
                value={formData.referralCode}
                onChangeText={(v) => setFormData({ ...formData, referralCode: v })}
                autoCapitalize="characters"
                autoCorrect={false}
              />
            </View>

            <TouchableOpacity 
              style={[styles.button, loading && styles.buttonDisabled]} 
              onPress={handleRegister}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#0f172a" />
              ) : (
                <Text style={styles.buttonText}>CREATE ACCOUNT</Text>
              )}
            </TouchableOpacity>

            <View style={styles.footer}>
              <Text style={styles.footerText}>Sudah punya akun? </Text>
              <Link href="/(auth)/login" asChild>
                <TouchableOpacity>
                  <Text style={styles.linkText}>Login</Text>
                </TouchableOpacity>
              </Link>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a' },
  scrollContent: { paddingHorizontal: 24, paddingVertical: 32, flexGrow: 1, justifyContent: 'center' },
  header: { alignItems: 'center', marginBottom: 32 },
  logo: { fontSize: 48, fontWeight: '900', color: '#fbbf24', letterSpacing: 4 },
  title: { fontSize: 24, fontWeight: '700', color: '#00f2ff', marginTop: -8, letterSpacing: 2 },
  subtitle: { fontSize: 14, color: '#64748b', marginTop: 8 },
  form: { gap: 16 },
  inputGroup: { gap: 8 },
  label: { fontSize: 13, fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase' },
  input: { backgroundColor: '#1e293b', borderRadius: 14, padding: 16, fontSize: 16, color: '#f8fafc', borderWidth: 1, borderColor: '#334155' },
  referralInput: { borderColor: '#fbbf24', borderStyle: 'dashed' },
  button: { backgroundColor: '#fbbf24', borderRadius: 14, paddingVertical: 18, alignItems: 'center', marginTop: 12, elevation: 4 },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#0f172a', fontSize: 16, fontWeight: '900' },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 20 },
  footerText: { color: '#64748b' },
  linkText: { color: '#fbbf24', fontWeight: '800' },
});