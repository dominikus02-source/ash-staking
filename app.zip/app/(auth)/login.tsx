import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, ScrollView, Image } from 'react-native';
import { useRouter, Link } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { signInWithEmailAndPassword, GoogleAuthProvider, signInWithCredential } from 'firebase/auth';

// PERBAIKAN: Path import disesuaikan dengan struktur folder app/(auth)/login.tsx
import { auth } from '../../src/lib/firebase'; // Keluar dua tingkat dari (auth) dan app
import { useAuthStore } from '../../src/stores/useAuthStore';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';

export default function LoginScreen() {
  const router = useRouter();
  
  // Tambahkan type 'any' atau sesuaikan dengan tipe store loe biar gak merah
  const setUser = useAuthStore((state: any) => state.setUser);  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

useEffect(() => {
  GoogleSignin.configure({
  webClientId: process.env.EXPO_PUBLIC_FIREBASE_WEB_CLIENT_ID,
  offlineAccess: true,
  });
}, []);

  const handleEmailLogin = async () => {
    const cleanEmail = email.trim();
    if (!cleanEmail || !password) {
      Alert.alert('⚠️ Input Kosong', 'Email dan password harus diisi!');
      return;
    }
    setLoading(true);
    try {
      // auth sekarang sudah terdefinisi dengan benar dari import di atas
      const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
      setUser(cred.user);
      router.replace('/(main)/dashboard');
    } catch (e: any) {
      console.log('Login Error:', e.code);
      Alert.alert('Login Gagal', mapError(e.code));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    try {
      await GoogleSignin.hasPlayServices();
      const signInResult = await GoogleSignin.signIn();
      
      // Mengikuti standar Google Sign-in v11+ (properti data)
      const idToken = signInResult.data?.idToken;

      if (!idToken) throw new Error("No ID Token found");

      const googleCredential = GoogleAuthProvider.credential(idToken);
      const res = await signInWithCredential(auth, googleCredential);
      
      setUser(res.user);
      router.replace('/(main)/dashboard');
    } catch (error: any) {
      console.log('Google Error:', error);
      
      if (error.code === statusCodes.SIGN_IN_CANCELLED) {
        // User cancel
      } else if (error.code === statusCodes.IN_PROGRESS) {
        Alert.alert('Proses Berjalan', 'Tunggu sebentar, login sedang diproses.');
      } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        Alert.alert('Error', 'Google Play Services tidak support atau tidak ada.');
      } else {
        Alert.alert('Google Sign-In Error', 'Gagal masuk. Cek SHA-1 di Firebase Console.');
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  const mapError = (code: string) => {
    const map: Record<string, string> = {
      'auth/user-not-found': 'Email belum terdaftar.',
      'auth/wrong-password': 'Password salah.',
      'auth/invalid-email': 'Format email salah.',
      'auth/invalid-credential': 'Email atau password salah.',
    };
    return map[code] || 'Terjadi kesalahan saat login.';
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          {/* PERBAIKAN: Pastikan path logo benar atau sesuaikan ke ../../assets */}
          <Image 
            source={require('../../assets/images/ash-icon.png')} 
            style={styles.logo} 
            resizeMode="contain" 
          />
          <Text style={styles.title}>ASH <Text style={styles.highlight}>PROTOCOL</Text></Text>
          <Text style={styles.subtitle}>Mining Revolution</Text>
        </View>

        <View style={styles.form}>
          <TextInput 
            style={styles.input} 
            placeholder="Email" 
            placeholderTextColor="#64748b" 
            value={email} 
            onChangeText={setEmail} 
            keyboardType="email-address" 
            autoCapitalize="none" 
          />
          <TextInput 
            style={styles.input} 
            placeholder="Password" 
            placeholderTextColor="#64748b" 
            value={password} 
            onChangeText={setPassword} 
            secureTextEntry 
          />

          <TouchableOpacity 
            style={[styles.btn, (loading || googleLoading) && { opacity: 0.7 }]} 
            onPress={handleEmailLogin} 
            disabled={loading || googleLoading}
          >
            {loading ? <ActivityIndicator color="#0f172a" /> : <Text style={styles.btnText}>LOGIN</Text>}
          </TouchableOpacity>

          <View style={styles.dividerContainer}>
            <View style={styles.divider} />
            <Text style={styles.dividerText}>ATAU</Text>
            <View style={styles.divider} />
          </View>

          <TouchableOpacity 
            style={styles.googleBtn} 
            onPress={handleGoogleLogin} 
            disabled={loading || googleLoading}
          >
            {googleLoading ? (
              <ActivityIndicator color="#fbbf24" />
            ) : (
              <>
                <Image 
                   source={{ uri: 'https://pngimg.com/uploads/google/google_PNG19635.png' }} 
                   style={styles.googleIcon} 
                />
                <Text style={styles.googleBtnText}>Masuk dengan Google</Text>
              </>
            )}
          </TouchableOpacity>

          <Link href="/(auth)/register" asChild>
            <TouchableOpacity style={styles.link}>
              <Text style={styles.linkText}>Belum punya akun? <Text style={{ color: '#fbbf24', fontWeight: 'bold' }}>Daftar</Text></Text>
            </TouchableOpacity>
          </Link>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a' },
  scroll: { flexGrow: 1, padding: 24, justifyContent: 'center' },
  header: { alignItems: 'center', marginBottom: 32 },
  logo: { width: 100, height: 100, marginBottom: 12 },
  title: { fontSize: 28, fontWeight: '900', color: '#fbbf24' },
  highlight: { color: '#00f2ff' },
  subtitle: { color: '#64748b', marginTop: 4, letterSpacing: 1 },
  form: { gap: 14 },
  input: { backgroundColor: '#1e293b', borderRadius: 14, padding: 16, color: '#fff', fontSize: 16, borderWidth: 1, borderColor: '#334155' },
  btn: { backgroundColor: '#fbbf24', borderRadius: 14, padding: 16, alignItems: 'center', marginTop: 8 },
  btnText: { color: '#0f172a', fontWeight: '800', fontSize: 16 },
  dividerContainer: { flexDirection: 'row', alignItems: 'center', marginVertical: 10 },
  divider: { flex: 1, height: 1, backgroundColor: '#334155' },
  dividerText: { color: '#64748b', paddingHorizontal: 10, fontSize: 12 },
  googleBtn: { flexDirection: 'row', backgroundColor: 'transparent', borderRadius: 14, padding: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#334155' },
  googleIcon: { width: 20, height: 20, marginRight: 12 },
  googleBtnText: { color: '#fff', fontWeight: '600', fontSize: 15 },
  link: { alignItems: 'center', marginTop: 16 },
  linkText: { color: '#64748b' }
});