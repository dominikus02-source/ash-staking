import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Redirect } from 'expo-router';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

// Pastikan path import ini benar (keluar 1 tingkat ke root, masuk ke src)
import { auth } from '../src/lib/firebase';
import { useAuthStore } from '../src/stores/useAuthStore';

export default function Index() {
  // Mengambil state dari zustand
  const setUser = useAuthStore((state) => state.setUser);
  const user = useAuthStore((state) => state.user);
  
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  useEffect(() => {
    console.log('[INDEX] 🔍 Verifying Node Connection...');

    // Kita bungkus dalam try-catch kecil untuk jaga-jaga jika auth belum terinisialisasi
    if (!auth) {
      console.error('[INDEX] ❌ Auth module not found!');
      setIsCheckingAuth(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser: FirebaseUser | null) => {
      try {
        if (firebaseUser) {
          console.log('[INDEX] ✅ Session Active:', firebaseUser.email);
          setUser(firebaseUser);
        } else {
          console.log('[INDEX] 👤 Guest Session');
          setUser(null);
        }
      } catch (error) {
        console.error('[INDEX] ❌ Auth Listener Error:', error);
      } finally {
        // Beri sedikit delay agar transisi tidak terlalu kaget (opsional)
        setIsCheckingAuth(false);
      }
    });

    return () => unsubscribe();
  }, [setUser]);

  // Loading screen premium look
  if (isCheckingAuth) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#fbbf24" />
        <View style={styles.textWrapper}>
          <Text style={styles.loaderText}>ASH PROTOCOL</Text>
          <Text style={styles.subText}>SYNCHRONIZING WITH BLOCKCHAIN...</Text>
        </View>
      </View>
    );
  }

  // Arahkan ke dashboard jika login, ke login jika tidak
  return <Redirect href={user ? "/(main)/dashboard" : "/(auth)/login"} />;
}

const styles = StyleSheet.create({
  loader: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    backgroundColor: '#0f172a' 
  },
  textWrapper: {
    alignItems: 'center',
    marginTop: 20,
  },
  loaderText: { 
    color: '#fbbf24', 
    fontWeight: '900',
    letterSpacing: 4, 
    fontSize: 18 
  },
  subText: {
    color: '#64748b',
    fontSize: 10,
    marginTop: 4,
    letterSpacing: 1
  }
});