import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Cpu, Crown, Gift, Pause, Play, Zap, Info } from 'lucide-react-native';
import React, { useEffect, useState, useRef } from 'react';
import { Alert, Animated, Dimensions, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next'; // <-- IMPORT TRANSLATE DI SINI

import { useTheme } from '../../src/context/ThemeContext';
import { useMiningSync } from '../../src/hooks/useMiningSync';
import { useAuthStore } from '../../src/stores/useAuthStore';
import MiningDiagnosticModal from '../../components/MiningDiagnosticModal';

// --- ADMOB IMPORTS ---
import { BannerAd, BannerAdSize, RewardedAd, RewardedAdEventType, TestIds } from 'react-native-google-mobile-ads';
import { AD_IDS } from '../../src/config/ads';

const { width } = Dimensions.get('window');
const MINING_DURATION_SEC = 21600;

const adUnitStandard = __DEV__ ? TestIds.REWARDED : AD_IDS.rewardedFree;
const adUnitPremium = __DEV__ ? TestIds.REWARDED : AD_IDS.rewardedPremium;

const standardRewardedAd = RewardedAd.createForAdRequest(adUnitStandard);
const premiumRewardedAd = RewardedAd.createForAdRequest(adUnitPremium);

export default function DashboardScreen() {
  const router = useRouter();
  const { userMeta } = useAuthStore();
  const { colors } = useTheme();
  const { t } = useTranslation(); // <-- PANGGIL FUNGSI T DI SINI
  
  const { 
    miningData, displayBalance, startMining, 
    claimMining, claimDailyBonus, activateNormalBoost, activatePremiumBoost 
  } = useMiningSync();
  
  const [showDiagnostic, setShowDiagnostic] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [progress, setProgress] = useState(0);
  const [calculatedBalance, setCalculatedBalance] = useState(0);
  const [hasClaimedToday, setHasClaimedToday] = useState(false);
  const [isStandardAdLoaded, setIsStandardAdLoaded] = useState(false);
  const [isPremiumAdLoaded, setIsPremiumAdLoaded] = useState(false);

  const pulseAnim = useRef(new Animated.Value(0)).current;
  const spinAnim = useRef(new Animated.Value(0)).current;

  const miningDataRef = useRef(miningData);
  useEffect(() => {
    miningDataRef.current = miningData;
  }, [miningData]);

  // SETUP REWARDED ADS
  useEffect(() => {
    const unsubEvents = [
      standardRewardedAd.addAdEventListener(RewardedAdEventType.LOADED, () => setIsStandardAdLoaded(true)),
      standardRewardedAd.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {
        activateNormalBoost();
        setIsStandardAdLoaded(false);
        standardRewardedAd.load();
      }),
      premiumRewardedAd.addAdEventListener(RewardedAdEventType.LOADED, () => setIsPremiumAdLoaded(true)),
      premiumRewardedAd.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {
        activatePremiumBoost();
        setIsPremiumAdLoaded(false);
        premiumRewardedAd.load();
      })
    ];
    standardRewardedAd.load();
    premiumRewardedAd.load();
    return () => unsubEvents.forEach(unsub => unsub());
  }, []);

  // DAILY CLAIM CHECKER
  useEffect(() => {
    if (miningData?.lastDailyClaim) {
      const lastClaim = new Date(miningData.lastDailyClaim).toDateString();
      const today = new Date().toDateString();
      setHasClaimedToday(lastClaim === today);
    }
  }, [miningData?.lastDailyClaim]);

  // MINING ANIMATION
  useEffect(() => {
    if (miningData?.mining?.isActive) {
      const loopPulse = () => {
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1, duration: 2000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 0, duration: 2000, useNativeDriver: true })
        ]).start(loopPulse);
      };
      loopPulse();

      const loopSpin = () => {
        Animated.timing(spinAnim, { toValue: 1, duration: 3000, useNativeDriver: true }).start(loopSpin);
      };
      loopSpin();
    } else {
      pulseAnim.setValue(0);
      spinAnim.setValue(0);
    }
  }, [miningData?.mining?.isActive]);

  // TIMER
  useEffect(() => {
    let interval: any;
    const isActive = miningData?.mining?.isActive;
    const startTimeRaw = miningData?.mining?.startTime;

    if (isActive && startTimeRaw) {
      let startMs = 0;
      if (typeof startTimeRaw === 'number') {
        startMs = startTimeRaw < 1e12 ? startTimeRaw * 1000 : startTimeRaw;
      } else if (typeof startTimeRaw === 'string') {
        startMs = new Date(startTimeRaw).getTime();
      } else if (startTimeRaw?.seconds) {
        startMs = startTimeRaw.seconds * 1000; 
      } else {
        startMs = new Date(startTimeRaw).getTime(); 
      }

      const now = Date.now();
      let elapsedSec = Math.floor((now - startMs) / 1000);
      if (elapsedSec < 0) elapsedSec = 0; 

      let currentRemaining = Math.max(0, MINING_DURATION_SEC - elapsedSec);
      let currentElapsed = Math.min(elapsedSec, MINING_DURATION_SEC);

      setTimeLeft(currentRemaining);
      setProgress((currentElapsed / MINING_DURATION_SEC) * 100);

      interval = setInterval(() => {
        currentRemaining -= 1;
        currentElapsed += 1;

        if (currentRemaining <= 0) {
          currentRemaining = 0;
          currentElapsed = MINING_DURATION_SEC;
          clearInterval(interval);
        }

        setTimeLeft(currentRemaining);
        setProgress((currentElapsed / MINING_DURATION_SEC) * 100);

        const hashrate = miningDataRef.current?.currentHashrate || 0;
        const baseBalance = miningDataRef.current?.balance || 0;
        const reward = currentElapsed * (hashrate / 3600);

        setCalculatedBalance(baseBalance + reward);
      }, 1000);
    } else {
      setTimeLeft(0);
      setProgress(0);
      setCalculatedBalance(miningData?.balance || 0);
    }
    return () => clearInterval(interval);
  }, [miningData?.mining?.isActive, miningData?.mining?.startTime]);

  const formatTime = (sec: number) => {
    if (isNaN(sec) || sec < 0) return "00:00:00";
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
  };

  const isMining = !!miningData?.mining?.isActive;
  const balance = displayBalance > 0 ? displayBalance : calculatedBalance;
  const statusColor = isMining ? (miningData?.isNormalBoostActive || miningData?.isPremiumBoostActive ? '#ef4444' : '#10b981') : '#94a3b8';

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        
        {/* HEADER */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: colors.textSecondary }]}>{t('dashboard.greeting')}</Text>
            <Text style={[styles.userName, { color: colors.text }]}>{userMeta?.displayName || 'Miner'}</Text>
          </View>
          <TouchableOpacity onPress={() => router.push('/profile')} style={styles.avatarBtn}>
            <Image source={{ uri: userMeta?.photoURL || 'https://via.placeholder.com/100' }} style={styles.avatarImage} />
          </TouchableOpacity>
        </View>

        {/* BALANCE CARD */}
        <LinearGradient colors={['#1e293b', '#0f172a']} style={styles.balanceCard}>
          <Text style={[styles.label, { color: '#64748b' }]}>{t('dashboard.balance_label')}</Text>
          <Text style={[styles.balance, { color: '#fbbf24' }]}>
             {isNaN(balance) ? '0.000000' : balance.toFixed(6)}
          </Text>
          <Text style={[styles.currency, { color: '#00f2ff' }]}>{t('dashboard.mainnet_asset')}</Text>
        </LinearGradient>

        {/* MINING ORB */}
        <View style={styles.orbWrapper}>
          <TouchableOpacity onPress={() => setShowDiagnostic(true)} style={styles.infoButton}>
            <Info size={18} color="#00f2ff" />
          </TouchableOpacity>

          <Animated.View style={[styles.glow, { backgroundColor: statusColor, opacity: pulseAnim.interpolate({ inputRange: [0, 1], outputRange: [0.05, 0.2] }) }]} />

          <View style={[styles.orb, { borderColor: statusColor }]}>
            <Animated.View style={{ transform: [{ rotate: spinAnim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] }}>
               <Cpu size={50} color={statusColor} />
            </Animated.View>
            <Text style={[styles.hashLabel, { color: statusColor }]}>{t('dashboard.hashrate')}</Text>
            <Text style={[styles.hashrateValue, { color: statusColor }]}>{(miningData?.currentHashrate || 0).toFixed(4)}</Text>
            <Text style={styles.timerText}>{formatTime(timeLeft)}</Text>
          </View>
        </View>

        {/* ACTION BUTTON */}
        <TouchableOpacity 
          style={[styles.mainBtn, isMining && { backgroundColor: '#334155' }]} 
          onPress={() => isMining ? claimMining() : startMining()}
        >
          {isMining ? <Pause size={22} color="#fff" /> : <Play size={22} color="#0f172a" />}
          <Text style={[styles.mainBtnText, isMining && { color: '#fff' }]}>
            {isMining ? t('dashboard.claim_mined') : t('dashboard.mine_now')}
          </Text>
        </TouchableOpacity>

        {/* DAILY BONUS CLAIM */}
        <TouchableOpacity 
          style={[styles.dailyBtn, hasClaimedToday && styles.dailyBtnDisabled]} 
          onPress={() => {
            if (!hasClaimedToday) {
              claimDailyBonus();
              setHasClaimedToday(true);
              Alert.alert(
                t('dashboard.bonus_alert_title'),
                t('dashboard.bonus_alert_msg'),
                [{ text: t('dashboard.bonus_alert_btn'), style: "default" }]
              );
            }
          }}
          disabled={hasClaimedToday}
        >
          <Gift size={20} color={hasClaimedToday ? "#64748b" : "#fff"} />
          <Text style={[styles.dailyBtnText, hasClaimedToday && { color: '#64748b' }]}>
            {hasClaimedToday ? t('dashboard.daily_claimed') : t('dashboard.claim_daily')}
          </Text>
        </TouchableOpacity>

        {/* AD BOOSTER SECTION */}
        <View style={styles.boostRow}>
          <TouchableOpacity 
            style={[styles.boostCard, miningData?.isNormalBoostActive && styles.boostCardActive]} 
            onPress={() => isStandardAdLoaded ? standardRewardedAd.show() : standardRewardedAd.load()}
            disabled={miningData?.isNormalBoostActive}
          >
            <Zap size={20} color="#fbbf24" />
            <View style={{flex:1}}><Text style={styles.boostName}>{t('dashboard.standard_boost')}</Text></View>
            <Text style={{color: '#fbbf24'}}>{miningData?.isNormalBoostActive ? t('dashboard.active') : t('dashboard.free')}</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.boostCard, { marginTop: 12 }, miningData?.isPremiumBoostActive && styles.boostCardActivePremium]} 
            onPress={() => isPremiumAdLoaded ? premiumRewardedAd.show() : premiumRewardedAd.load()}
            disabled={miningData?.isPremiumBoostActive}
          >
            <Crown size={20} color="#00f2ff" />
            <View style={{flex:1}}><Text style={styles.boostName}>{t('dashboard.premium_boost')}</Text></View>
            <Text style={{color: '#00f2ff'}}>{miningData?.isPremiumBoostActive ? t('dashboard.active') : '14 ASH'}</Text>
          </TouchableOpacity>
        </View>

      </ScrollView>

      {/* BANNER AD */}
      <View style={styles.bannerContainer}>
        <BannerAd unitId={__DEV__ ? TestIds.BANNER : AD_IDS.bannerMarket} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
      </View>

      <MiningDiagnosticModal 
        visible={showDiagnostic} 
        onClose={() => setShowDiagnostic(false)} 
        hashrate={miningData?.currentHashrate || 0}
        isBoostActive={!!(miningData?.isNormalBoostActive || miningData?.isPremiumBoostActive)}
        boostMultiplier={miningData?.isNormalBoostActive || miningData?.isPremiumBoostActive ? 0.5 : 0}
        teamRewardPercent={0} 
      />    
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 120 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting: { fontSize: 14 },
  userName: { fontSize: 22, fontWeight: 'bold' },
  avatarBtn: { width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: '#fbbf24', overflow: 'hidden' },
  avatarImage: { width: '100%', height: '100%' },
  balanceCard: { borderRadius: 20, padding: 20, marginBottom: 25 },
  label: { fontSize: 11, fontWeight: 'bold', letterSpacing: 1 },
  balance: { fontSize: 32, fontWeight: '800' },
  currency: { fontSize: 12, fontWeight: 'bold' },
  orbWrapper: { width: '100%', alignItems: 'center', justifyContent: 'center', marginVertical: 20 },
  orb: { width: width * 0.6, height: width * 0.6, borderRadius: 999, borderWidth: 3, justifyContent: 'center', alignItems: 'center', backgroundColor: '#1e293b' },
  glow: { position: 'absolute', width: width * 0.7, height: width * 0.7, borderRadius: 999 },
  hashLabel: { fontSize: 10, letterSpacing: 2, marginTop: 10 },
  hashrateValue: { fontSize: 28, fontWeight: 'bold' },
  timerText: { fontSize: 16, fontFamily: 'monospace', color: '#fff', marginTop: 5 },
  mainBtn: { flexDirection: 'row', backgroundColor: '#fbbf24', padding: 18, borderRadius: 15, justifyContent: 'center', alignItems: 'center', gap: 10 },
  mainBtnText: { fontSize: 16, fontWeight: '900', color: '#0f172a' },
  dailyBtn: { flexDirection: 'row', backgroundColor: '#10b981', padding: 18, borderRadius: 15, justifyContent: 'center', alignItems: 'center', gap: 10, marginTop: 15 },
  dailyBtnDisabled: { backgroundColor: '#1e293b', borderColor: '#334155', borderWidth: 1 },
  dailyBtnText: { fontSize: 16, fontWeight: '900', color: '#fff' },
  boostRow: { marginTop: 25 },
  boostCard: { flexDirection: 'row', backgroundColor: '#1e293b', padding: 15, borderRadius: 12, alignItems: 'center', gap: 10, borderWidth: 1, borderColor: '#334155' },
  boostCardActive: { borderColor: '#fbbf24' },
  boostCardActivePremium: { borderColor: '#00f2ff' },
  boostName: { color: '#fff', fontWeight: 'bold' },
  infoButton: { position: 'absolute', top: 0, right: 10, zIndex: 10, backgroundColor: '#0f172a', padding: 8, borderRadius: 10 },
  bannerContainer: { position: 'absolute', bottom: 0, width: '100%', alignItems: 'center' }
});