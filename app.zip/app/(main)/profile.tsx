// app/(main)/profile.tsx
import * as LocalAuthentication from 'expo-local-authentication';
import { useRouter } from 'expo-router'; 
import { signOut } from 'firebase/auth'; 
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import {
  Camera,
  ChevronRight,
  Edit2,
  FileText,
  Globe,
  Lock,
  LogOut, Moon,
  ShieldCheck,
  Sun
} from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { Alert, Image, Linking, Modal, ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { auth, db } from '../../src/lib/firebase'; 
import { useAuthStore } from '../../src/stores/useAuthStore';
// UPDATE: Hapus useTheme lama, kita pakai murni dari Zustand
import { translations, useSettingsStore, themes } from '../../src/stores/useSettingsStore'; 

export default function ProfileScreen() {
  const router = useRouter();
  const { user, userMeta, clearUser, setMeta } = useAuthStore();
  const { language, theme, setLanguage, setTheme } = useSettingsStore();
  
  // UPDATE: Tarik warna dari Zustand berdasarkan tema aktif
  const colors = themes[theme];
  const t = translations[language] || translations['en']; // Fallback aman

  // State Lokal
  const [isEditingName, setIsEditingName] = useState(false);
  const [newName, setNewName] = useState(userMeta?.displayName || '');
  const [hasEdited, setHasEdited] = useState(false); 
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [twoFAEnabled, setTwoFAEnabled] = useState(false);

  useEffect(() => {
    const checkStatus = async () => {
      if (!user) return;
      try {
        const userRef = doc(db, 'users', user.uid);
        const snap = await getDoc(userRef);
        if (snap.exists()) {
          const data = snap.data();
          setHasEdited(data.hasEditedProfile || false);
          setBiometricEnabled(data.security?.biometric || false);
          setTwoFAEnabled(data.security?.twoFA || false);
          if (data.displayName && !userMeta?.displayName) setNewName(data.displayName);
        }
      } catch (error) {
        console.error("Error checking profile status:", error);
      }
    };
    checkStatus();
  }, [user]);

  const handleSaveName = async () => {
    if (!newName.trim()) return;
    try {
      const userRef = doc(db, 'users', user!.uid);
      await updateDoc(userRef, { displayName: newName, hasEditedProfile: true });
      setMeta({ displayName: newName });
      setHasEdited(true);
      setIsEditingName(false);
      Alert.alert('Success', 'Nama berhasil diubah.');
    } catch (error) {
      Alert.alert('Error', 'Gagal menyimpan nama');
    }
  };

  const toggleBiometric = async () => {
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    if (!hasHardware) {
      Alert.alert('Not Supported', 'Device ini tidak mendukung biometrik.');
      return;
    }
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Verify Identity',
      fallbackLabel: 'Use PIN',
    });
    if (result.success) {
      const newStatus = !biometricEnabled;
      setBiometricEnabled(newStatus);
      await updateDoc(doc(db, 'users', user!.uid), { 'security.biometric': newStatus });
    }
  };

  const handleTwoFAChange = async (val: boolean) => {
    setTwoFAEnabled(val);
    await updateDoc(doc(db, 'users', user!.uid), { 'security.twoFA': val });
  };

  const handleLogout = async () => {
    Alert.alert("Logout", "Yakin mau keluar?", [
        { text: "Batal", style: "cancel" },
        { text: "Keluar", onPress: async () => {
            try {
              await signOut(auth);
              clearUser();
              router.replace('/'); 
            } catch (error) {
              Alert.alert("Error", "Gagal logout.");
            }
          } 
        }
    ]);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        <View style={styles.header}>
          <TouchableOpacity onPress={() => Alert.alert('Coming Soon', 'Upload photo coming soon')} style={styles.avatarWrapper}>
            <Image source={{ uri: userMeta?.photoURL || 'https://via.placeholder.com/150' }} style={styles.avatar} />
            <Camera size={16} color="#fff" style={styles.cameraIcon} />
          </TouchableOpacity>
          <Text style={[styles.name, { color: colors.text }]}>{userMeta?.displayName || 'Miner'}</Text>
          <Text style={[styles.email, { color: colors.textSecondary }]}>@{userMeta?.username || user?.email?.split('@')[0]}</Text>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{t.account || 'ACCOUNT'}</Text>
        <View style={[styles.menuGroup, { borderColor: colors.border }]}>
          <TouchableOpacity 
            style={[styles.menuItem, { borderBottomColor: colors.border, opacity: hasEdited ? 0.5 : 1 }]}
            onPress={() => !hasEdited && setIsEditingName(true)}
            disabled={hasEdited}
          >
            <Edit2 size={20} color={hasEdited ? colors.textSecondary : colors.primary} />
            <Text style={[styles.menuText, { color: colors.text }]}>{hasEdited ? 'Name Locked' : 'Edit Name & Username'}</Text>
            {hasEdited ? <Lock size={16} color={colors.error} /> : <ChevronRight size={16} color={colors.textSecondary} />}
          </TouchableOpacity>
          <TouchableOpacity style={[styles.menuItem, { borderBottomWidth: 0 }]} onPress={() => router.push('/kyc')}>
            <ShieldCheck size={20} color={colors.success} />
            <Text style={[styles.menuText, { color: colors.text }]}>{t.kyc || 'KYC Verification'}</Text>
            <ChevronRight size={16} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{t.security || 'SECURITY'}</Text>
        <View style={[styles.menuGroup, { borderColor: colors.border }]}>
          <View style={[styles.menuItem, { borderBottomColor: colors.border, justifyContent: 'space-between' }]}>
            <View style={{flexDirection: 'row', alignItems: 'center', gap: 12}}>
              <Lock size={20} color={colors.primary} />
              <View>
                <Text style={[styles.menuText, { color: colors.text }]}>Biometric Login</Text>
                <Text style={[styles.subText, { color: colors.textSecondary }]}>Use FaceID/Fingerprint</Text>
              </View>
            </View>
            <Switch 
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={biometricEnabled ? "#fff" : "#f4f3f4"}
              onValueChange={toggleBiometric}
              value={biometricEnabled}
            />
          </View>
          <View style={[styles.menuItem, { borderBottomWidth: 0, justifyContent: 'space-between' }]}>
            <View style={{flexDirection: 'row', alignItems: 'center', gap: 12}}>
              <ShieldCheck size={20} color={colors.primary} />
              <View>
                <Text style={[styles.menuText, { color: colors.text }]}>2-Factor Auth</Text>
                <Text style={[styles.subText, { color: colors.textSecondary }]}>Extra security layer</Text>
              </View>
            </View>
             <Switch 
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={twoFAEnabled ? "#fff" : "#f4f3f4"}
              onValueChange={handleTwoFAChange}
              value={twoFAEnabled}
            />
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{t.resources || 'RESOURCES'}</Text>
        <View style={[styles.menuGroup, { borderColor: colors.border }]}>
          <TouchableOpacity style={[styles.menuItem, { borderBottomColor: colors.border }]} onPress={() => Linking.openURL('https://ashcoin-landing.web.app/')}>
            <Globe size={20} color={colors.primary} />
            <Text style={[styles.menuText, { color: colors.text }]}>Official Website</Text>
            <ChevronRight size={16} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.menuItem, { borderBottomWidth: 0 }]} onPress={() => Linking.openURL('https://ashcoin-landing.web.app/ASH_Protocol_Ultimate_Whitepaper_v1.2.pdf')}>
            <FileText size={20} color={colors.primary} />
            <Text style={[styles.menuText, { color: colors.text }]}>Whitepaper</Text>
            <ChevronRight size={16} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={[styles.menuGroup, { marginTop: 20, borderColor: colors.border }]}>
           <TouchableOpacity style={[styles.menuItem, { borderBottomColor: colors.border }]} onPress={() => setLanguage(language === 'id' ? 'en' : 'id')}>
            <Globe size={20} color={colors.textSecondary} />
            <Text style={[styles.menuText, { color: colors.text }]}>{t.language || 'Language'}: {language.toUpperCase()}</Text>
            <ChevronRight size={16} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.menuItem, { borderBottomWidth: 0 }]} onPress={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
            {theme === 'dark' ? <Sun size={20} color={colors.primary} /> : <Moon size={20} color={colors.textSecondary} />}
            <Text style={[styles.menuText, { color: colors.text }]}>{t.theme || 'Theme'}: {theme === 'dark' ? (t.dark || 'Dark') : (t.light || 'Light')}</Text>
            <ChevronRight size={16} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={[styles.logoutBtn, { backgroundColor: colors.border }]} onPress={handleLogout}>
          <LogOut size={20} color={colors.error} />
          <Text style={[styles.logoutText, { color: colors.error }]}>{t.logout || 'Logout'}</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* MODAL EDIT NAMA (Warna Dynamic) */}
      <Modal visible={isEditingName} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1 }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Edit Profile</Text>
            
            <Text style={{color: colors.textSecondary, marginBottom: 4, fontSize: 12}}>Display Name</Text>
            <TextInput 
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              value={newName} onChangeText={setNewName}
              placeholder="Enter your name" placeholderTextColor={colors.textSecondary}
            />
            
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.btn, { backgroundColor: colors.border }]} onPress={() => setIsEditingName(false)}>
                <Text style={{ color: colors.text, fontWeight: '700' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, { backgroundColor: colors.primary }]} onPress={handleSaveName}>
                <Text style={{ color: theme === 'dark' ? '#0f172a' : '#fff', fontWeight: '700' }}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 24, paddingBottom: 40 },
  header: { alignItems: 'center', marginBottom: 32 },
  avatarWrapper: { width: 80, height: 80, borderRadius: 40, overflow: 'hidden', marginBottom: 12, borderWidth: 2, borderColor: '#fbbf24' },
  avatar: { width: '100%', height: '100%' },
  cameraIcon: { position: 'absolute', bottom: 0, right: 0, backgroundColor: '#0f172a', padding: 4, borderRadius: 12 },
  name: { fontSize: 22, fontWeight: '700' },
  email: { fontSize: 14, marginTop: 4 },
  sectionTitle: { fontSize: 14, fontWeight: '700', marginBottom: 8, marginTop: 16, letterSpacing: 1 },
  menuGroup: { borderRadius: 16, overflow: 'hidden', borderWidth: 1 },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12, borderBottomWidth: 1 },
  menuText: { fontSize: 16, fontWeight: '500', flex: 1 },
  subText: { fontSize: 12, marginTop: 2 }, 
  logoutBtn: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 32, padding: 16, borderRadius: 16 },
  logoutText: { fontWeight: '700', fontSize: 16 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '85%', borderRadius: 24, padding: 24 },
  modalTitle: { fontSize: 20, fontWeight: '700', marginBottom: 20, textAlign: 'center' },
  input: { borderWidth: 1, borderRadius: 12, padding: 12, marginBottom: 10 },
  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 10 },
  btn: { flex: 1, padding: 12, borderRadius: 12, alignItems: 'center' }
});