// app/(main)/wallet.tsx
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowDownLeft, ArrowUpRight, Copy, Lock, Minus, Plus, Send, Wifi } from 'lucide-react-native';
import React from 'react';
import { Alert, Linking, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useMiningSync } from '../../src/hooks/useMiningSync';
import { PI_CONFIG, isPiBrowser } from '../../src/lib/piConfig';
import { themes, useSettingsStore } from '../../src/stores/useSettingsStore';

export default function WalletScreen() {
  // UPDATE: Panggil displayBalance biar sinkron sama pergerakan Dashboard
  const { miningData, displayBalance } = useMiningSync();
  const { language, theme } = useSettingsStore();
  
  // Ambil warna berdasarkan tema aktif
  const colors = themes[theme];

  // UPDATE: Logic balance disamakan dengan Dashboard biar nggak belang
  const liquidBalance = displayBalance > 0 ? displayBalance : (miningData?.balance || 0);
  
  // Status KYC (Dummy: false = belum, true = sudah)
  const isKycVerified = false; 

  // Hitung Konversi Mata Uang (Fix Rp 10.000)
  const getFiatValue = (ashAmount: number) => {
    if (language === 'id') {
      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(ashAmount * PI_CONFIG.ashPriceIdr);
    } else {
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(ashAmount * PI_CONFIG.ashPriceUsd);
    }
  };

  // Fungsi Connect ke Pi Browser
  const handleConnectPi = () => {
    if (isPiBrowser()) {
      Alert.alert('Pi Connected', 'You are running inside Pi Browser.');
    } else {
      Linking.openURL(PI_CONFIG.appUrl);
    }
  };

  const handleSendAsh = () => {
    if (!isKycVerified) {
      Alert.alert('KYC Required', 'You must complete KYC verification to send ASH.');
      return;
    }
    if (liquidBalance <= 0) {
      Alert.alert('Insufficient Balance', 'You have no liquid ASH to send.');
      return;
    }
    Alert.alert('Send ASH', 'Open P2P Transfer Interface...');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        {/* HEADER */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.text }]}>WALLET</Text>
          <TouchableOpacity onPress={() => {
            Alert.alert('Copy Address', `Address copied: ${PI_CONFIG.walletAddress}`);
          }}>
            <Copy size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        {/* MAIN BALANCE CARD */}
        <LinearGradient colors={[colors.card, colors.background]} style={styles.balanceCard}>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Available Balance</Text>
          {/* UPDATE: Pakai toFixed(6) biar geraknya kelihatan mulus kayak di Dashboard */}
          <Text style={[styles.balance, { color: colors.text }]}>{liquidBalance.toFixed(6)}</Text>
          <Text style={[styles.currency, { color: colors.primary }]}>ASH</Text>
          
          {/* FIAT CONVERSION (Rp 10.000 Fix) */}
          <Text style={[styles.fiatValue, { color: colors.textSecondary }]}>{getFiatValue(liquidBalance)}</Text>

          {/* ACTIONS ROW */}
          <View style={styles.actionsRow}>
            <TouchableOpacity 
              style={[styles.actionBtn, { backgroundColor: colors.border }]} 
              onPress={() => Alert.alert('Deposit', 'Deposit via Bank/Card coming soon')}
            >
              <Plus size={18} color={colors.text} />
              <Text style={[styles.actionText, { color: colors.text }]}>Deposit</Text>
            </TouchableOpacity>

            <TouchableOpacity style={[styles.actionBtn, styles.lockedBtn, { backgroundColor: colors.border }]} disabled>
              <Minus size={18} color={colors.textSecondary} />
              <Text style={[styles.actionText, { color: colors.textSecondary }]}>Withdraw</Text>
            </TouchableOpacity>

             <TouchableOpacity 
                style={[styles.actionBtn, !isKycVerified && styles.kycLockedBtn, { backgroundColor: colors.card, borderColor: colors.border }]} 
                onPress={handleSendAsh}
              >
              <Send size={18} color={isKycVerified ? colors.text : colors.textSecondary} />
              <Text style={[styles.actionText, { color: isKycVerified ? colors.text : colors.textSecondary }]}>
                {isKycVerified ? 'Send' : 'KYC Req'}
              </Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>

        {/* STAKED BALANCE (LOCKED FUNDS) */}
        <View style={[styles.stakedCard, { backgroundColor: colors.card, borderColor: colors.primary }]}>
          <View style={{flexDirection: 'row', alignItems: 'center', gap: 8}}>
            <Lock size={16} color={colors.primary} />
            <Text style={[styles.stakedLabel, { color: colors.primary }]}>Staked & Locked</Text>
          </View>
          <Text style={[styles.stakedBalance, { color: colors.text }]}>0.0000 ASH</Text>
          <Text style={[styles.stakedDesc, { color: colors.textSecondary }]}>These funds are earning rewards and cannot be moved.</Text>
        </View>

        {/* PI NETWORK BRIDGE */}
        <TouchableOpacity style={[styles.piCard, { backgroundColor: colors.card, borderColor: '#00ff88' }]} onPress={handleConnectPi}>
          <View style={[styles.piIcon, { backgroundColor: 'rgba(0,255,136,0.1)' }]}><Wifi size={24} color="#00ff88" /></View>
          <View style={{flex: 1}}>
            <Text style={[styles.piTitle, { color: colors.text }]}>Connect Pi Network</Text>
            <Text style={[styles.piDesc, { color: colors.textSecondary }]}>Bridge assets via Pi Browser</Text>
          </View>
          <ArrowUpRight size={20} color={colors.textSecondary} />
        </TouchableOpacity>

        {/* TRANSACTION HISTORY */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Recent Transactions</Text>
          
          {[
            { id: 1, title: 'Mining Reward', date: 'Today', amount: '+0.0480 ASH', icon: 'ArrowDownLeft', color: '#00ff88' },
            { id: 2, title: 'Stake Lock', date: 'Yesterday', amount: '-10.00 ASH', icon: 'ArrowUpRight', color: '#fbbf24' },
          ].map((tx) => (
            <View key={tx.id} style={[styles.txItem, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={[styles.txIcon, { backgroundColor: tx.color === '#00ff88' ? 'rgba(0,255,136,0.1)' : 'rgba(251, 191, 36, 0.1)' }]}>
                {tx.icon === 'ArrowDownLeft' ? <ArrowDownLeft size={20} color={tx.color} /> : <ArrowUpRight size={20} color={tx.color} />}
              </View>
              <View style={{flex: 1}}>
                <Text style={[styles.txTitle, { color: colors.text }]}>{tx.title}</Text>
                <Text style={[styles.txDate, { color: colors.textSecondary }]}>{tx.date}</Text>
              </View>
              <Text style={[styles.txAmount, { color: tx.amount.startsWith('+') ? '#00ff88' : colors.text }]}>{tx.amount}</Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 24, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  title: { fontSize: 24, fontWeight: '900' },
  balanceCard: { borderRadius: 24, padding: 24, marginBottom: 20, borderWidth: 1, alignItems: 'center' },
  label: { fontSize: 14, marginBottom: 8 },
  balance: { fontSize: 36, fontWeight: '800', letterSpacing: -1 },
  currency: { fontSize: 16, fontWeight: '600', marginTop: 4, marginBottom: 4 },
  fiatValue: { fontSize: 14, marginBottom: 20 },
  actionsRow: { flexDirection: 'row', gap: 10, width: '100%' },
  actionBtn: { flex: 1, flexDirection: 'row', paddingVertical: 12, borderRadius: 12, alignItems: 'center', justifyContent: 'center', gap: 6 },
  lockedBtn: { opacity: 0.5 },
  kycLockedBtn: { borderStyle: 'dashed', borderWidth: 1 },
  actionText: { fontWeight: '700', fontSize: 12 },
  stakedCard: { borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 1 },
  stakedLabel: { fontSize: 12, fontWeight: '700' },
  stakedBalance: { fontSize: 20, fontWeight: '800', marginTop: 4 },
  stakedDesc: { fontSize: 11, marginTop: 4 },
  piCard: { flexDirection: 'row', padding: 16, borderRadius: 16, alignItems: 'center', gap: 12, marginBottom: 24, borderWidth: 1 },
  piIcon: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  piTitle: { fontSize: 16, fontWeight: '700' },
  piDesc: { fontSize: 12, marginTop: 2 },
  section: { marginBottom: 20 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 16 },
  txItem: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 16, marginBottom: 12, borderWidth: 1 },
  txIcon: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  txTitle: { fontSize: 16, fontWeight: '600' },
  txDate: { fontSize: 12, marginTop: 2 },
  txAmount: { fontSize: 16, fontWeight: '700', fontFamily: 'monospace' }
});