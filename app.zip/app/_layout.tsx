import '../src/locales/i18n';
import React, { useEffect } from 'react';
import { useColorScheme, LogBox } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts } from 'expo-font';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Pastikan path ThemeProvider sudah benar sesuai struktur src loe
import { ThemeProvider } from '../src/context/ThemeContext';

// Tahan Splash Screen biar nggak kedip sebelum font/data siap
SplashScreen.preventAutoHideAsync();

// Abaikan warning yang nggak penting kalau perlu (opsional)
LogBox.ignoreLogs(['Reading asycn storage']); 

export default function RootLayout() {
  const [loaded, error] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
    ...FontAwesome.font,
  });

  // Handle error saat load font
  useEffect(() => {
    if (error) {
      console.error("Font Load Error:", error);
      throw error;
    }
  }, [error]);

  // Sembunyikan Splash Screen kalau font sudah siap
  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ThemeProvider>
        <SafeAreaProvider>
          <RootLayoutNav />
        </SafeAreaProvider>
      </ThemeProvider>
    </GestureHandlerRootView>
  );
}

function RootLayoutNav() {
  const colorScheme = useColorScheme();

  return (
    <>
      {/* StatusBar biar otomatis ganti warna font (putih/hitam) sesuai tema */}
      <StatusBar style={colorScheme === 'dark' ? 'light' : 'dark'} />
      
      <Stack 
        screenOptions={{ 
          headerShown: false,
          animation: 'fade_from_bottom', // Animasi transisi yang lebih halus
        }}
      >
        {/* Entry point: Cek Auth Status */}
        <Stack.Screen name="index" /> 

        {/* Auth Group: Login, Register, Forgot Password */}
        <Stack.Screen 
          name="(auth)" 
          options={{ 
            animation: 'fade',
            gestureEnabled: false // User nggak bisa swipe back ke splash
          }} 
        />

        {/* Main Group: Dashboard, Mining, Wallet, dll */}
        <Stack.Screen 
          name="(main)" 
          options={{ 
            animation: 'fade' 
          }} 
        />
        
        {/* Modal Pages */}
        <Stack.Screen 
          name="kyc" 
          options={{ 
            presentation: 'modal',
            headerShown: true, // Kasih header dikit buat modal kyc
            headerTitle: 'Verification' 
          }} 
        />

        <Stack.Screen 
          name="modal" 
          options={{ 
            presentation: 'transparentModal',
            animation: 'slide_from_bottom'
          }} 
        />
      </Stack>
    </>
  );
}