// src/stores/useAuthStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from 'firebase/auth';

interface UserMeta {
  displayName?: string | null;
  email?: string | null;
  photoURL?: string | null;
  uid?: string;
  username?: string; // Tambahin username biar nggak error di profile
}

interface AuthState {
  user: User | null;
  userMeta: UserMeta | null;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  setMeta: (meta: Partial<UserMeta>) => void;
  setLoading: (loading: boolean) => void;
  clearUser: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      userMeta: null,
      isLoading: true,
      setUser: (user) => set({ user, isLoading: false }),
      setMeta: (meta) => set((state) => ({ userMeta: { ...state.userMeta, ...meta } })),
      setLoading: (loading) => set({ isLoading: loading }),
      clearUser: () => set({ user: null, userMeta: null, isLoading: false }),
    }),
    {
      name: 'ash-auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ user: state.user, userMeta: state.userMeta }),
    }
  )
);