import { useEffect, useState } from 'react';
import { doc, getDoc, setDoc, onSnapshot, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuthStore } from '../stores/useAuthStore';

// KONSTANTA
const BASIC_HASHRATE = 0.048; 
const BOOST_MULTIPLIER = 0.5; 
const NORMAL_BOOST_DURATION_MS = 30 * 60 * 1000; 
const PREMIUM_BOOST_DURATION_MS = 7 * 24 * 60 * 60 * 1000; 
const PREMIUM_COST = 14; 
const MINING_DURATION_SEC = 21600; // 6 jam

export function useMiningSync() {
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [miningData, setMiningData] = useState<any>(null);
  const [docReady, setDocReady] = useState(false);
  
  // State untuk tampilan angka saldo yang bertambah real-time di UI
  const [displayBalance, setDisplayBalance] = useState(0);

  // 1. SETUP FIREBASE & LISTENER
  useEffect(() => {
    if (!user?.uid) return; // Lebih aman pakai user?.uid
    
    console.log('[MINING_SYNC] Initializing for user:', user.uid);
    const userRef = doc(db, 'users', user.uid);
    setLoading(true);

    const initUser = async () => {
      try {
        const snap = await getDoc(userRef);
        if (!snap.exists()) {
          console.log('[MINING_SYNC] Creating new user document...');
          await setDoc(userRef, {
            balance: 2.0,
            mining: { isActive: false, startTime: null, lastSync: Date.now() },
            boosts: { normalEndTime: 0, premiumEndTime: 0 },
            createdAt: Date.now(),
            lastDailyClaim: 0
          });
        } else {
          const data = snap.data();
          // Migration: Pastikan field penting ada
          if (!data.balance && data.ashBalance) {
            await updateDoc(userRef, { balance: data.ashBalance });
          }
        }
        setDocReady(true);
        setLoading(false);
      } catch (e) {
        console.error('[MINING_SYNC] Init failed:', e);
        setLoading(false);
      }
    };
    initUser();

    // Listener Real-time dari Firebase
    const unsubscribe = onSnapshot(userRef, (docSnap) => {
      if (!docSnap.exists()) return;
      const data = docSnap.data()!;
      
      let currentHashrate = BASIC_HASHRATE;
      const now = Date.now();
      
      // Cek Boost
      if (data.boosts?.normalEndTime && now < data.boosts.normalEndTime) {
        currentHashrate += BASIC_HASHRATE * BOOST_MULTIPLIER;
      } 
      else if (data.boosts?.premiumEndTime && now < data.boosts.premiumEndTime) {
        currentHashrate += BASIC_HASHRATE * BOOST_MULTIPLIER;
      }

      let calculatedBalance = data.balance || 0;
      let timeLeft = 0;

      if (data.mining?.isActive === true && data.mining?.startTime) {
        const startMs = data.mining.startTime;
        const durationSec = (now - startMs) / 1000;
        const elapsed = Math.min(durationSec, MINING_DURATION_SEC);
        
        const reward = elapsed * (currentHashrate / 3600);
        calculatedBalance += reward;
        timeLeft = Math.max(0, MINING_DURATION_SEC - elapsed);
      }

      setMiningData({ 
        ...data, 
        calculatedBalance, 
        timeLeft, 
        currentHashrate,
        isNormalBoostActive: data.boosts?.normalEndTime > now,
        isPremiumBoostActive: data.boosts?.premiumEndTime > now,
        normalBoostTimeLeft: Math.max(0, (data.boosts?.normalEndTime || 0) - now),
        premiumBoostTimeLeft: Math.max(0, (data.boosts?.premiumEndTime || 0) - now)
      });
    });

    return () => unsubscribe();
  }, [user?.uid]); // <-- INI YANG GUE UBAH BIAR GAK BERAT

  // 2. LOGIKA TICKER (UI Saldo Berjalan)
  useEffect(() => {
    let interval: any = null; // Fix merah TS aman di sini
    
    if (miningData?.mining?.isActive && miningData?.mining?.startTime) {
      interval = setInterval(() => {
        const now = Date.now();
        const elapsedSec = Math.min((now - miningData.mining.startTime) / 1000, MINING_DURATION_SEC);
        const reward = elapsedSec * (miningData.currentHashrate / 3600);
        
        setDisplayBalance((miningData.balance || 0) + reward);
      }, 50); 
    } else {
      setDisplayBalance(miningData?.balance || 0);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [miningData?.mining?.isActive, miningData?.mining?.startTime, miningData?.balance, miningData?.currentHashrate]);

  // ACTIONS
  const startMining = async () => {
    if (!user || !docReady || miningData?.mining?.isActive) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        'mining.isActive': true,
        'mining.startTime': Date.now(),
        'mining.lastSync': Date.now()
      });
    } catch (error) {
      console.error('[MINING_SYNC] Start failed:', error);
    }
  };

  const claimMining = async () => {
    if (!user || !docReady || !miningData?.mining?.isActive) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        balance: miningData.calculatedBalance,
        'mining.isActive': false,
        'mining.startTime': null,
        'mining.lastSync': Date.now()
      });
    } catch (error) {
      console.error('[MINING_SYNC] Claim failed:', error);
    }
  };

  const claimDailyBonus = async () => {
    if (!user || !docReady) return;
    const today = new Date().toDateString();
    const lastClaimDate = new Date(miningData.lastDailyClaim).toDateString();

    if (today === lastClaimDate) {
      alert('Already claimed today!');
      return;
    }

    try {
      await updateDoc(doc(db, 'users', user.uid), {
        balance: (miningData.calculatedBalance || 0) + 0.005,
        lastDailyClaim: Date.now()
      });
    } catch (error) {
      alert('Gagal klaim bonus harian.');
    }
  };

  const activateNormalBoost = async () => {
    if (!user || !docReady) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        'boosts.normalEndTime': Date.now() + NORMAL_BOOST_DURATION_MS
      });
    } catch (error) {
      console.error('Boost failed:', error);
    }
  };

  const activatePremiumBoost = async () => {
    if (!user || !docReady) return;
    if ((miningData.calculatedBalance || 0) < PREMIUM_COST) {
      alert('Saldo tidak cukup!');
      return;
    }
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        balance: miningData.calculatedBalance - PREMIUM_COST,
        'boosts.premiumEndTime': Date.now() + PREMIUM_BOOST_DURATION_MS
      });
    } catch (error) {
      console.error('Premium Boost failed:', error);
    }
  };

  return { 
    loading, 
    miningData, 
    displayBalance, 
    startMining, 
    claimMining, 
    claimDailyBonus, 
    activateNormalBoost, 
    activatePremiumBoost 
  };
}